@extends('templates.base')
@section('title', 'Home')
@section('h1', 'Bem-vindos à página')

@section('content')
<p>Você entrou no site</p>
@endsection